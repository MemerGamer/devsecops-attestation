G7 throwaway fixture metadata
